import sys
import yaml
import json

filename = sys.argv[1]
with open(filename, "r") as f:
    d = yaml.safe_load(f)

with open(filename, "w") as f:
    f.write(json.dumps(d, indent=2))
