#!/usr/bin/python3
# coding=utf-8

# -------------------------------------------------------------------------------
# This file is part of Phobos, a Blender Add-On to edit robot models.
# Copyright (C) 2020 University of Bremen & DFKI GmbH Robotics Innovation Center
#
# You should have received a copy of the 3-Clause BSD License in the LICENSE file.
# If not, see <https://opensource.org/licenses/BSD-3-Clause>.
# -------------------------------------------------------------------------------

import os
import json
import bpy
import phobos.defs as defs
import phobos.model.models as models
import phobos.utils.io as ioUtils
import phobos.utils.blender as bUtils
from phobos.io.entities.urdf import sort_urdf_elements
from phobos.phoboslog import log


def deriveEntity(root, outpath):
    """Derives the dictionary for a SMURF entity from the phobos model dictionary.

    # TODO savetosubfolder is not a parameter

    Args:
      root(bpy.types.Object): The smurf root object.
      outpath(str): The path to export the smurf to.
      savetosubfolder(bool): If True the export path has a subfolder for this smurf entity.

    Returns:
      : dict - An entry for the scenes entitiesList

    """
    entitypose = models.deriveObjectPose(root)
    entity = models.initObjectProperties(root, 'entity', ['link', 'joint', 'motor'])
    if 'parent' not in entity and 'joint/type' in root and root['joint/type'] == 'fixed':
        entity['parent'] = 'world'
    entity["position"] = entitypose["translation"]
    entity["rotation"] = entitypose["rotation_quaternion"]

    # check model data if entity is a reference
    # FIXME: this part is broken but not used at the moment anyways
    if "isReference" in entity:
        entity.pop("isReference")
        bpy.ops.scene.reload_models_and_poses_operator()
        modelsPosesColl = bUtils.getPhobosPreferences().models_poses
        for robot_model in modelsPosesColl:
            if (root["model/name"] == robot_model.robot_name) and (
                root["entity/pose"] == robot_model.label
            ):
                pass
        entity['file'] = os.path.join(
            os.path.relpath(robot_model.path, outpath), root["name"] + ".smurf"
        )
        """
        with open(os.path.join(os.path.dirname(defs.__file__), "RobotLib.yml"), "r") as f:
            robots = json.loads(f.read())
            sourcepath = robots[smurf["model/name"]]
            for filename in os.listdir(sourcepath):
                fullpath = os.path.join(sourcepath, filename)
                if os.path.isfile(fullpath):
                    shutil.copy2(fullpath, os.path.join(smurf_outpath, filename))
                else:
                    # remove old folders to prevent errors in copytree
                    shutil.rmtree(os.path.join(smurf_outpath, filename), True)
                    shutil.copytree(fullpath, os.path.join(smurf_outpath, filename))
        """
    else:
        modelpath = os.path.join(outpath, root['model/name'], 'smurf')
        # TODO why the spacing between the paths?
        log("Scene paths: " + outpath + ' ' + modelpath, "DEBUG")
        entity['file'] = os.path.join(
            os.path.relpath(modelpath, os.path.dirname(outpath)), root['model/name'] + ".smurf"
        )
    return entity


def deriveRefinedCollisionData(model):
    """This function collects all collision bitmasks in a given model.

    Args:
      model(dict): The robot model to search in.

    Returns:
      : dict -- a dictionary containing all bitmasks with corresponding element name (key).

    """
    collisiondata = {}
    for linkname in model['links']:
        for elementname in model['links'][linkname]['collision']:
            element = model['links'][linkname]['collision'][elementname]
            data = {
                key: element[key]
                for key in (a for a in element.keys() if a not in ['geometry', 'name', 'pose'])
            }
            if data:
                data['name'] = model['links'][linkname]['collision'][elementname]['name']
                data['link'] = linkname
                collisiondata[elementname] = data
    return collisiondata

def exportGazeboXacro(model, path):
    """This function exports a given model to a specific path as a smurf representation.

    Args:
      model(dict): The model you want to export.
      path: The path you want to save the smurf file *without file name!*

    Returns:

    """
    collisiondata = deriveRefinedCollisionData(model)

    # create all filenames
    fileorder = [
        'collision',
        'visuals',
        'materials',
        'motors',
        'sensors',
        'controllers',
        'state',
        'lights',
        'submechanisms',
    ]
    urdf_path = '../urdf/'
    urdf_filename = model['name'] + '.urdf'

    # gather annotations and data from text files
    annotationdict = models.gatherAnnotations(model)

    # $mars annotated properties overwrite custom properties of objects for smurf
    if 'mars' in annotationdict:
        for category in annotationdict['mars']:
            for list_obj in annotationdict['mars'][category]:
                model[category + 's'][list_obj['name']].update(list_obj)
        del annotationdict['mars']

    infostring = ' definition Gazebo xacro file for "' + model['name'] + '", ' + model["date"] + "\n\n"

    # write model information
    xacro_filename = model['name'] + ".gazebo.xacro"
    xacro_movables_filename = model['name'] + "_movables.gazebo.xacro"
    gazebo_controller_filename = model['name'] + "_controller_config.yml"

    ros_package = ioUtils.getRosPackageName()
    log("Writing Gazebo xacro model to " + xacro_filename, "INFO")

    # we parse the controller parameters into the motors

    for motor in model['motors']:
        motordict = model['motors'][motor]
        controllerparams = {}
        if 'controller' in  motordict and motordict['controller'] in model['controllers']:
            controllerparams = {
                key: value
                for key, value in model['controllers'][motordict['controller']].items()
                if (key not in ['name', 'target'])
            }
            motordict.update(controllerparams)
            del motordict['controller']
        else:
            log("No controller assigned to motor {}!".format(motordict['name']), 'WARNING')

        # PID controlled motors get their min and max values from the joint limits
        if motordict['type'] == 'PID' or motordict['type'] == 'generic_bldc':
            try:
                joint = model['joints'][motordict['joint']]
                if 'limits' in joint:
                    motordict['minValue'] = joint['limits']['lower']
                    motordict['maxValue'] = joint['limits']['upper']
            except KeyError:
                log(
                    "Missing data in motor {}! No limits given for type PID. Motor might be incomplete.".format(
                        motordict['name']
                    ),
                    "WARNING",
                )
        # direct controllers are called generic_dc in mars
        elif motordict['type'] == 'direct':
            motordict['type'] = 'generic_dc'
            try:
                motordict['minValue'] = -1. * motordict["maxSpeed"]
                motordict['maxValue'] = motordict["maxSpeed"]
            except KeyError:
                log(
                    "Missing data in motor {}! No maxSpeed given for motor type direct. Motor might be incomplete.".format(
                        motordict['name']
                    ),
                    "WARNING",
                )

    with open(os.path.join(path, xacro_filename), "w") as f:
        f.write('<?xml version=\"1.0\"?>\n\n')
        f.write('<robot name="'+model["name"]+'" xmlns:xacro=\"http://www.ros.org/wiki/xacro\">\n')
        f.write('<xacro:include filename="$(find '+ros_package+')/urdf/'+model["name"]+'.urdf" />\n')
        f.write('<xacro:include filename="$(find '+ros_package+')/gazebo_xacro/'+model["name"]+'_movables.gazebo.xacro" />\n')
        f.write('\n</robot>\n')

    with open(os.path.join(path, xacro_movables_filename), "w") as f:
        f.write("<?xml version=\"1.0\"?>\n")
        f.write("<robot xmlns:xacro=\"http://www.ros.org/wiki/xacro\">\n")
        f.write("\n")
        f.write("    <gazebo>\n")
        f.write('        <plugin name="gazebo_ros_control" filename="libgazebo_ros_control.so">\n')
        f.write('            <robotNamespace>/'+model["name"]+'</robotNamespace>\n')
        f.write('            <robotSimType>gazebo_ros_control/DefaultRobotHWSim</robotSimType>\n')
        f.write('        </plugin>\n')
        f.write('    </gazebo>\n')
        if "motors" in model:
            for key,value in model["motors"].items():
                print(key)
                print(value)
                hardwareInterface = "VelocityJointInterface"
                if value["type"] == "PID" or value["type"] == "generic_bldc":
                    hardwareInterface = "PositionJointInterface"
                f.write('\n')
                f.write('    <transmission name="'+key+'_transmission">\n')
                f.write('      <type>transmission_interface/SimpleTransmission</type>\n')
                f.write('      <joint name="'+value["joint"]+'">\n')
                f.write('        <hardwareInterface>hardware_interface/'+hardwareInterface+'</hardwareInterface>\n')
                f.write('      </joint>\n')
                f.write('      <actuator name="'+key+'_actuator">\n')
                f.write('        <hardwareInterface>hardware_interface/'+hardwareInterface+'</hardwareInterface>\n')
                f.write('        <mechanicalReduction>1</mechanicalReduction>\n')
                f.write('      </actuator>\n')
                f.write('    </transmission>\n')
                
        f.write("</robot>\n")

    # write controller config for gazebo
    controlDict = {}
    # first add default joint_state_controller:
    controlDict["joint_state_controller"] = {"type": "joint_state_controller/JointStateController", "publish_rate": 50}
    # then collect controller information
    if "motors" in model:
        for key,value in model["motors"].items():
            if value["type"] == "PID" or value["type"] == "generic_bldc":
                controlDict[key+"_controller"] = {"type": "position_controllers/JointPositionController", "joint": value["joint"],
                                                  "pid": {"p": value["p"], "i": value["i"], "d": value["d"]}}
            elif value["type"] == "generic_dc":
                # load pid values from motor if available
                controlDict[key+"_controller"] = {"type": "velocity_controllers/JointVelocityController", "joint": value["joint"],
                                                  "pid": {"p": 100.0, "i": 0.01, "d": 10.0}}
                
    with open(os.path.join(path, gazebo_controller_filename), "w") as f:
        f.write(json.dumps(controlDict))

# TODO: implement everything but joints

    # write materials, sensors, motors & controllers
    # for data in ['materials', 'motors', 'sensors', 'controllers', 'lights']:
    #     if exportdata[data]:
    #         log("Writing {} to smurf file.".format(data), 'DEBUG')
    #         with open(os.path.join(path, filenames[data]), 'w') as op:
    #             op.write('#' + data + infostring)
    #             op.write(
    #                 json.dumps(
    #                     sort_for_yaml_dump({data: list(model[data].values())}, data),
    #                     indent=2
    #                 )
    #             )

    
    # write additional collision information
    # if exportdata['collision']:
    #     with open(os.path.join(path, filenames['collision']), 'w') as op:
    #         op.write('#collision data' + infostring)
    #         # TODO delete me?
    #         # op.write(json.dumps({'collision': list(bitmasks.values())}, indent=2))
    #         op.write(
    #             json.dumps(
    #                 {'collision': [collisiondata[key] for key in sorted(collisiondata.keys())]},
    #                 indent=2
    #             )
    #         )

    # # write additional information
    # for category in annotationdict.keys():
    #     if category != 'sdf':
    #         if exportdata[category]:
    #             outstring = '#' + category + infostring
    #             for elementtype in annotationdict[category]:
    #                 outstring += elementtype + ':\n'
    #                 outstring += (
    #                     json.dumps(annotationdict[category][elementtype], indent=2)
    #                     + "\n"
    #                 )
    #             with open(os.path.join(path, filenames[category]), 'w') as op:
    #                 op.write(outstring)

    # write custom data from textfiles
    # for data in customdatalist:
    #     if exportdata[data]:
    #         with open(os.path.join(path, filenames[data]), 'w') as op:
    #             op.write('#' + data + infostring)
    #             op.write(json.dumps({data: list(model[data].values())}, indent=2))


    # TODO delete me?
    ## write custom yml files
    # if bpy.data.window_managers[0].exportCustomData:
    #    log("Exporting custom files to to " + path + "...", "INFO")
    #    for text in customtexts:
    #        with open(os.path.join(path, text.name), 'w') as op:
    #            op.write('\n'.join(line.body for line in text.lines))


# CHECK why is this class disabled?
# class SMURFModelParser(RobotModelParser):
#     """Class derived from RobotModelParser which parses a SMURF model"""
#
#     def __init__(self, filepath):
#         RobotModelParser.__init__(self, filepath)
#
#     def parseModel(self):
#         print("Parsing SMURF model...")
#         #smurf = None
#         # TODO check for filename consistency (for Windows)
#         with open(self.filepath, 'r') as smurffile:
#             smurf = json.loads(smurffile)
#         if smurf is None:
#             log('No valid SMURF file.', "ERROR")
#             return None
#         urdffile = None
#         srdffile = None
#         # TODO check filename consistency (Windows)
#         ymlfiles = [f for f in smurf['files'] if f.endswith('.yml') or f.endswith('.yaml')]
#         for f in smurf['files']:
#             if f.endswith('.urdf'):
#                 urdffile = f
#             if f.endswith('.srdf'):
#                 srdffile = f
#         # get URDF info
#         if urdffile is None:
#             log("Did not find URDF file associated with SMURF.", "ERROR")
#             return None
#         urdfparser = URDFModelParser(os.path.join(self.path, urdffile))
#         urdfparser.parseModel()
#         if srdffile is not None:
#             srdfparser = SRDFModelParser(os.path.join(self.path, srdffile))
#             self.robot = srdfparser.parseModel(urdfparser.robot)
#         else:
#             self.robot = urdfparser.robot
#         # make sure all types exist
#         typelist = ['links', 'joints', 'materials', 'sensors', 'motors', 'controllers', 'groups', 'chains']
#         for key in typelist:
#             if key not in self.robot:
#                 self.robot[key] = {}
#         #add the smurf information
#         custom_dicts = {}
#         for yml in ymlfiles:
#             with open(os.path.join(self.path, yml), 'r') as ymlfile:
#                 ymldict = json.loads(ymlfile)
#             for key in ymldict:
#                 print(key)
#                 if key in ['materials', 'sensors', 'motors', 'controllers']:
#                     for element in ymldict[key]:
#                         if element['name'] not in self.robot[key]:
#                             self.robot[key][element['name']] = element
#                         else:
#                             for tag in element:
#                                 self.robot[key][element['name']][tag] = element[tag]
#                 elif key in 'state':
#                 # TODO: handle state
#                     pass
#                 else:
#                     custom_dicts[key] = ymldict[key]
#
#         for key in custom_dicts:
#             print('assign custom properties:', key, custom_dicts[key])
#             for element in custom_dicts[key]:  # iterate over list with custom annotations
#                 print(element)
#                 try:
#                     objtype = element['type']
#                 except KeyError:
#                     log("Could not find 'type' in custom annotation: " + str(element), "ERROR")
#                 try:
#                     objname = element['name']
#                 except KeyError:
#                     log("Could not find 'name' in custom annotation: " + str(element), "ERROR")
#                 try:
#                 #FIXME: this is a total hack!
#                     if objtype+'s' in typelist:
#                         objtype += 's'
#                     else:
#                         raise TypeError(objtype)
#                     if objname in self.robot[objtype]:
#                         for tag in element:
#                             if tag not in ['type', 'name']:
#                                 if not '$'+key in self.robot[objtype][objname]:
#                                     self.robot[objtype][objname]['$'+key] = {tag: element[tag]}
#                                 else:
#                                     self.robot[objtype][objname]['$'+key][tag] = element[tag]
#                     else:
#                         raise NameError(objname)
#                 except TypeError:
#                     print("ERROR: could not find 'type' or 'name' in custom annotation", objtype, objname)
#                 except NameError:
#                     log("Element " + str(objname) + " of type " + str(objtype) + " does not exist in this model.", "ERROR")
#
#         #now some debug output
#         with open(self.filepath+'_SMURF_debug.yml', 'w') as outputfile:
#             outputfile.write(json.dumps(self.robot)) #last parameter prevents inline formatting for lists and dictionaries


# registering import/export functions of types with Phobos
entity_type_dict = {
    'gazebo_xacro': {'export': exportGazeboXacro, 'derive': deriveEntity, 'extensions': ('xacro',)}
}
